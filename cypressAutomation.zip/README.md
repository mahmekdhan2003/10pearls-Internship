# Cypress Automation - SauceDemo

This project automates UI testing for the [SauceDemo](https://www.saucedemo.com/) website using Cypress.

## Features
- Login failure scenario
- Login success flow and homepage validation
- Product navigation and validation
- Reusable steps via custom commands
- Page Object Model (POM) structure

## Run Tests
```bash
npm install
npx cypress open
```
