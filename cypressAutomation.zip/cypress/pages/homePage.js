class HomePage {
  getTitle() {
    return cy.get('.title');
  }

  getInventoryItems() {
    return cy.get('.inventory_item');
  }
}

export default new HomePage();
