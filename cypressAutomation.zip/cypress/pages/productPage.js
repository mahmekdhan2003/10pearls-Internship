class ProductPage {
  openFirstProduct() {
    cy.get('.inventory_item_name').first().click();
  }

  getProductTitle() {
    return cy.get('.inventory_details_name');
  }
}

export default new ProductPage();
