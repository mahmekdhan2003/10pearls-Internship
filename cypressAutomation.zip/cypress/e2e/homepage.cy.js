import LoginPage from '../pages/loginPage';
import HomePage from '../pages/homePage';

describe('Home Page Validation', () => {

  beforeEach(() => {
    LoginPage.visit();
    LoginPage.enterUsername('standard_user');
    LoginPage.enterPassword('secret_sauce');
    LoginPage.clickLogin();
  });

  it('Validate homepage title and products', () => {
    HomePage.getTitle().should('have.text', 'Products');
    HomePage.getInventoryItems().should('have.length.greaterThan', 0);
  });

});
