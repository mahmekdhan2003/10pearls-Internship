import LoginPage from '../pages/loginPage';

describe('Login Tests', () => {

  beforeEach(() => {
    LoginPage.visit();
  });

  it('Login Failure - Invalid Credentials', () => {
    LoginPage.enterUsername('wrong_user');
    LoginPage.enterPassword('wrong_pass');
    LoginPage.clickLogin();
    LoginPage.getErrorMessage().should('be.visible');
  });

  it('Login Success - Valid Credentials', () => {
    LoginPage.enterUsername('standard_user');
    LoginPage.enterPassword('secret_sauce');
    LoginPage.clickLogin();
    cy.url().should('include', '/inventory.html');
  });

});
