import LoginPage from '../pages/loginPage';
import ProductPage from '../pages/productPage';

describe('Product Navigation and Validation', () => {

  beforeEach(() => {
    LoginPage.visit();
    LoginPage.enterUsername('standard_user');
    LoginPage.enterPassword('secret_sauce');
    LoginPage.clickLogin();
  });

  it('Open first product and validate details', () => {
    ProductPage.openFirstProduct();
    ProductPage.getProductTitle().should('be.visible');
  });

});
