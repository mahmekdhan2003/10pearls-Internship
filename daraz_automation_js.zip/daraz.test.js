const { test, expect } = require('@playwright/test');

test('Daraz.pk automation with filters and assertions', async ({ page }) => {
    await page.goto('https://www.daraz.pk/');
    await page.fill('input[name="q"]', 'electronics');
    await page.keyboard.press('Enter');
    await page.waitForTimeout(3000);

    try {
        await page.waitForSelector('a.c16H9d', { timeout: 10000 });
        const brandLink = page.locator('text=Samsung').first();
        if (await brandLink.count() > 0) {
            await brandLink.click();
            await page.waitForTimeout(3000);
        }
    } catch (err) {}

    try {
        await page.fill('input[name="price_min"]', '500');
        await page.fill('input[name="price_max"]', '5000');
        await page.click('button.c3e8SH');
        await page.waitForTimeout(3000);
    } catch (err) {}

    const products = await page.locator('div.c16H9d a').count();
    expect(products).toBeGreaterThan(0);

    await page.locator('div.c16H9d a').first().click();
    await page.waitForTimeout(3000);

    const bodyText = await page.textContent('body');
    const freeShipping = bodyText.toLowerCase().includes('free shipping');
    console.log('Free Shipping Available:', freeShipping);
});
