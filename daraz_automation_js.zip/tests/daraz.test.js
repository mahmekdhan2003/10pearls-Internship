const { test, expect } = require('@playwright/test');
const { HomePage } = require('../pages/homePage');
const { SearchResultsPage } = require('../pages/searchResultsPage');
const { ProductPage } = require('../pages/productPage');

test('Daraz automation test', async ({ page }) => {
    const home = new HomePage(page);
    const searchPage = new SearchResultsPage(page);
    const productPage = new ProductPage(page);

    await home.open();
    await home.search('electronics');

    await searchPage.applyBrandFilter('Samsung');
    await searchPage.applyPriceFilter(500, 5000);

    const productCount = await searchPage.countProducts();
    expect(productCount).toBeGreaterThan(0);

    await searchPage.openFirstProduct();

    const freeShipping = await productPage.verifyFreeShipping();
    console.log('Free Shipping Available:', freeShipping);
});
