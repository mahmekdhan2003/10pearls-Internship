exports.ProductPage = class ProductPage {
    constructor(page) {
        this.page = page;
    }
    async verifyFreeShipping() {
        await this.page.waitForTimeout(3000);
        const bodyText = await this.page.textContent('body');
        return bodyText.toLowerCase().includes('free shipping');
    }
};
