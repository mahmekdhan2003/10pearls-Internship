exports.SearchResultsPage = class SearchResultsPage {
    constructor(page) {
        this.page = page;
    }
    async applyBrandFilter(brandName) {
        await this.page.waitForSelector('a.c16H9d', { timeout: 10000 });
        const brandLink = this.page.locator(`text=${brandName}`).first();
        if (await brandLink.count() > 0) {
            await brandLink.click();
            await this.page.waitForTimeout(3000);
        }
    }
    async applyPriceFilter(min, max) {
        await this.page.fill('input[name="price_min"]', String(min));
        await this.page.fill('input[name="price_max"]', String(max));
        await this.page.click('button.c3e8SH');
        await this.page.waitForTimeout(3000);
    }
    async countProducts() {
        const products = await this.page.locator('div.c16H9d a').count();
        return products;
    }
    async openFirstProduct() {
        await this.page.locator('div.c16H9d a').first().click();
    }
};
