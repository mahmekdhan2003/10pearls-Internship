exports.HomePage = class HomePage {
    constructor(page) {
        this.page = page;
        this.searchBox = 'input[name="q"]';
    }
    async open() {
        await this.page.goto('https://www.daraz.pk/');
    }
    async search(query) {
        await this.page.fill(this.searchBox, query);
        await this.page.keyboard.press('Enter');
        await this.page.waitForTimeout(3000);
    }
};
